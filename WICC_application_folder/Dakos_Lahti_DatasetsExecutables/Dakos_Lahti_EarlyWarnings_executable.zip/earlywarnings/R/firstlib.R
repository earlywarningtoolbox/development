.onAttach <- function(lib, pkg)
{
   packageStartupMessage("\nearlywarnings Copyright (C) 2011-2013 Vasilis Dakos et al.\nThis program comes with ABSOLUTELY NO WARRANTY.\nThis is free software, and you are welcome to redistribute it under the FreeBSD open source license. For more information, see http://www.early-warning-signals.org\n")

}
