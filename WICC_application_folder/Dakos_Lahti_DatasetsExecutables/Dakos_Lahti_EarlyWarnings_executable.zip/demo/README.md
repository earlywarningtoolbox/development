Early Warnings Toolbox Demo
====

To test Early Warnings Toolbox, run in R:

```r
install.packages("shiny"); library(shiny); shiny::runGitHub("demo", "earlywarningtoolbox")
```

